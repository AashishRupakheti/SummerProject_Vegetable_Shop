-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2023 at 07:50 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(10) NOT NULL,
  `cart_user_id` int(3) NOT NULL,
  `cart_product_id` int(3) NOT NULL,
  `cart_quentity` int(3) NOT NULL,
  `cart_total_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notifi_id` int(3) NOT NULL,
  `notifi_cust_id` int(3) NOT NULL,
  `notifi_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notifi_notice` varchar(50) NOT NULL,
  `notifi_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notifi_id`, `notifi_cust_id`, `notifi_date`, `notifi_notice`, `notifi_status`) VALUES
(41, 9, '2022-07-27 12:40:50', 'You Have New Order', 'Read'),
(42, 14, '2022-07-28 03:36:49', 'You Have New Order', 'Read'),
(43, 9, '2022-08-11 08:56:01', 'Your Order Shiped!', 'Read_usr'),
(44, 1, '2022-08-18 01:15:19', 'You Have New Order', 'Read'),
(45, 1, '2022-08-18 01:15:22', 'You Have New Order', 'Read'),
(46, 1, '2022-08-18 01:15:25', 'You Have New Order', 'Read'),
(47, 1, '2022-08-18 01:15:30', 'You Have New Order', 'Read'),
(48, 1, '2022-08-18 01:15:32', 'You Have New Order', 'Read'),
(49, 9, '2022-08-18 01:16:06', 'Your Order Shiped!', 'Read_usr'),
(50, 9, '2022-08-18 01:16:08', 'Your Order Shiped!', 'Read_usr'),
(51, 9, '2022-08-18 01:16:13', 'Your Order Shiped!', 'Read_usr'),
(52, 9, '2022-08-18 01:16:18', 'Your Order Shiped!', 'Read_usr'),
(53, 9, '2022-08-18 01:16:23', 'Your Order Shiped!', 'Read_usr'),
(54, 9, '2022-08-31 23:33:26', 'You Have New Order', 'Read'),
(55, 9, '2022-09-04 03:39:07', 'You Have New Order', 'Read'),
(56, 9, '2022-09-04 06:57:28', 'Your Order Canceld!', 'Read_usr'),
(57, 9, '2022-09-04 06:57:31', 'Your Order Canceld!', 'Read_usr'),
(58, 9, '2022-09-13 06:55:18', 'You Have New Order', 'Read'),
(59, 9, '2022-09-13 06:55:36', 'Your Order Canceld!', 'New_adm');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(3) NOT NULL,
  `order_user_id` int(3) NOT NULL,
  `order_product_id` int(3) NOT NULL,
  `order_quentity` int(2) NOT NULL,
  `order_total_price` int(10) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_user_id`, `order_product_id`, `order_quentity`, `order_total_price`, `order_date`, `order_status`) VALUES
(46, 9, 26, 1, 300, '2022-07-27 12:40:50', 'Completed'),
(47, 14, 4, 10, 400, '2022-07-28 03:36:49', 'Shiped'),
(48, 1, 2, 1, 60, '2022-08-18 01:15:19', 'Shiped'),
(49, 1, 8, 1, 45, '2022-08-18 01:15:22', 'Shiped'),
(50, 1, 15, 1, 60, '2022-08-18 01:15:25', 'Shiped'),
(51, 1, 14, 1, 100, '2022-08-18 01:15:30', 'Shiped'),
(52, 1, 18, 5, 275, '2022-08-18 01:15:32', 'Shiped'),
(53, 9, 26, 2, 600, '2022-08-31 23:33:26', 'Canceld'),
(54, 9, 2, 1, 60, '2022-09-04 03:39:07', 'Canceld'),
(55, 9, 2, 1, 60, '2022-09-13 06:55:18', 'Canceld');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(3) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_category` varchar(50) NOT NULL,
  `product_price` int(6) NOT NULL,
  `product_size` int(4) NOT NULL,
  `product_description` varchar(800) NOT NULL,
  `product_image` varchar(500) NOT NULL,
  `Season` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_brand`, `product_category`, `product_price`, `product_size`, `product_description`, `product_image`, `Season`) VALUES
(1, 'Beetroot', 'Nepali', 'Vegetables', 150, 1, 'The beetroot is the taproot portion of a beet plant, usually known in North America as beets while the vegetable is referred to as beetroot in British English, and also known as the table beet, garden beet, red beet, dinner beet or golden beet.', 'beetroot.jpg', 'winter'),
(2, 'Bitter Gourd', 'Nepali', 'Vegetables', 60, 1, 'Bitter gourd is a green-skinned vegetable with white to translucent flesh and a taste that fits its name.', 'bitter_gourd.jpg', 'Summer'),
(3, 'Boad Beans', 'Nepali', 'Vegetables', 70, 1, 'broad bean, (Vicia faba), also called fava bean or faba bean, species of legume (family Fabaceae) widely cultivated for its edible seeds. ', 'boad_beans.jpg', 'autumn'),
(4, 'Bottle Gourd', 'Nepali', 'Vegetables', 40, 1, 'Bottle Gourd is a bottle shaped vegetable upto 1m long with light green smooth skin and white flesh.It is considered as healthy vegetable.people suffering from jaundice drink the juice of this vegetable. ', 'bottle_gourd.jpg', 'summer'),
(5, 'Bitter Gourd(small)', 'Nepali Terai', 'Vegetables', 80, 1, 'Bitter gourd is a green-skinned vegetable with white to translucent flesh and a taste that fits its name.', 'bittergourd_small.jpg', NULL),
(6, 'Brinjal Purple', 'Nepali', 'Vegetables', 50, 1, 'Long purple brinjal is a member of the nightshade family. The brinjal is a white-coloured fruit that is edible. The skin of the long purple brinjal is tough', 'brinjal_purple.jpg', NULL),
(7, 'Brinjal Vari', 'Nepali Terai', 'Vegetables', 60, 1, 'Eggplant, aubergine or brinjal is a plant species in the nightshade family Solanaceae. Solanum melongena is grown worldwide for its edible fruit.', 'brinjal_vari.jpg', NULL),
(8, 'Cabbage', 'Nepali', 'Vegetables', 45, 1, 'Cabbage, comprising several cultivars of Brassica oleracea, is a leafy green, red (purple), or white (pale green) biennial plant grown as an annual vegetable crop for its dense-leaved heads', 'cabbage2.jpg', NULL),
(9, 'Carrot', 'Bhaktapur', 'Vegetables', 100, 1, 'The carrot (Daucus carota subsp. sativus) is a root vegetable, typically orange in color, though purple, black, red, white, and yellow cultivars exist all of which are domesticated forms of the wild carrot, Daucus carota, native to Europe and Southwestern Asia. ', 'carrot.jpg', NULL),
(10, 'Cauliflower', 'Palung', 'Vegetables', 80, 1, ' Cauliflower (Brassica oleracea L. var. botrytis) is a popular winter season vegetable crop grown throughout the world. It is also the most important vegetable crop in Nepal.', 'cauli_flower.jpg', 'summer'),
(11, 'Cluster Beans', 'Indian', 'Vegetables', 90, 1, 'Cluster beans are legumes small to medium in size, which are long and narrow with tapered ends. They are green-coloured when immature and yellow-green when immature. ', 'Cluster-Beans.jpg', NULL),
(12, 'Cucumber', 'Local', 'Vegetables', 80, 1, 'Cucumber (Cucumis sativus) is a widely-cultivated creeping vine plant in the Cucurbitaceae family that bears usually cylindrical fruits, which are used as culinary vegetables. Considered an annual plant, there are three main varieties of cucumber — slicing, pickling, and burpless/seedless — within which several cultivars have been created.', 'cucumber.jpg', 'summer'),
(13, 'Green Capsigum', 'Nepali Terai', 'Vegetables', 180, 1, '', 'green_capsigum.jpg', NULL),
(14, 'Green Chilli', 'Nepali', 'Vegetables', 100, 1, '', 'green-chilli.jpg\r\n', NULL),
(15, 'Ladies Finger', 'Nepali Terai', 'Vegetables', 60, 1, '', 'ladies-finger.jpg', NULL),
(16, 'Onion', 'Indian', 'Vegetables', 65, 1, 'The onion (Allium cepa L., from Latin cepa meaning \"onion\"), also known as the bulb onion or common onion, is a vegetable that is the most widely cultivated species of the genus Allium.', 'onion.jpg', NULL),
(17, 'Parwal', 'Nepali Terai', 'Vegetables', 70, 1, 'The parwal (pointed gourd) is used as a dioecious, herbaceous vegetable. The crop is of Indo-Malayan origin and grown extensively in eastern India and, to a lesser extent, in other parts of South Asia.', 'PARWAL.JPG\r\n', NULL),
(18, 'Potato', 'Nepali', 'Vegetables', 55, 1, 'The potato is a starchy tuber of the plant Solanum tuberosum and is a root vegetable native to the Americas. Mostly it is grown in all parts of world.', 'potato.jpg', NULL),
(19, 'Radish', 'Nepali', 'Vegetables', 40, 1, 'The radish (Raphanus raphanistrum subsp. sativus) is an edible root vegetable of the family Brassicaceae that was domesticated in Asia prior to Roman times. Radishes are grown and consumed throughout the world, being mostly eaten raw as a crunchy salad vegetable with a pungent flavor.', 'radish.jpg', NULL),
(20, 'Raw Banana', 'Indian', 'Vegetables', 130, 1, 'Raw banana is a vegetable used to prepare a banana curry.', 'raw-banana.jpg', NULL),
(21, 'Rigde Gourd', 'Indian', 'Vegetables', 80, 1, 'Rigde Gourd is a climbing vine belongs to gourds and cucumbers Family. It is known as Dishrag vine or Loofah. Rigde Gourd looks like a cucumber and is arrow straight, slightly curved, or very curved. It is Green in color', 'ridge-gourd.jpg', NULL),
(22, 'Big Tomato', 'Indian', 'Vegetables', 80, 1, 'The tomato is the edible berry of the plant Solanum lycopersicum, commonly known as the tomato plant. The species originated in western South America, Mexico, and Central America. ', 'tomato_big.jpg', NULL),
(23, 'Small Tomato', 'Nepali', 'Vegetables', 70, 1, 'The tomato is the edible berry of the plant Solanum lycopersicum, commonly known as the tomato plant. The species originated in western South America, Mexico, and Central America. ', 'tomato_small.jpg', 'summer'),
(24, 'Yellow Pumkin', 'Nepali Terai', 'Vegetables', 60, 1, 'Taste Mellow Yellow pumpkins are large, averaging 25 to 27 centimeters in diameter and 27 to 30 centimeters in length, and have a uniform, round shape with prominent, vertical ribbing. The rind is smooth and bright yellow, connecting to a straight, rough, and brown-green stem.', 'yellow-pumkin.jpg', NULL),
(25, 'Grapes', 'Nepali Terai', 'Fruits', 190, 1, '', '1605685243_Grapes-green-seedless.jpg', 'spring'),
(26, 'Apple(fuji)', 'Chinese', 'Fruits', 300, 1, 'Fuji apples are typically round and range from large to very large, averaging 75 millimetres (3.0 in) in diameter. They contain between 9–11% sugars by weight and have a dense flesh that is sweeter and crisper than many other apple cultivars, making them popular with consumers around the world.', '1537632696_apple-shimla.jpg', 'summer'),
(27, 'Papaya', 'Nepali Terai', 'Fruits', 110, 1, 'Papaya is a soft tropical fruit with a yellowish-orange color. Its taste depends on whether you’re eating ripe or unripe papaya. When ripe, papaya is sweet and has a flavor comparable to a melon. Unripe papaya, on the other hand, may have little to no flavor', '1531142657_papaya.jpg', 'Summer'),
(28, 'Pomegranate', 'Indain', 'Fruits', 350, 1, '', '1531142636_pomogranate-kabul.jpg', 'summer'),
(29, 'Amla', '`Nepali', 'Fruits', 150, 1, '', '1531142511_amla.jpg', 'summer'),
(30, 'Pineapple', 'Nepali Terai', 'Fruits', 125, 1, '', '1531142497_pinapple2.jpg', NULL),
(31, 'Sapotta', 'Indian', 'Fruits', 150, 1, '', '1531142475_sapotta.jpg', NULL),
(32, 'Guava', 'Nepali', 'Fruits', 80, 1, '', '1531142452_guava-white.jpg', 'autumn'),
(33, 'Strawberry', 'Nepali', 'Fruits', 150, 1, '', '1531142424_strawberry.jpg', 'summer'),
(34, 'WaterMellon', 'Nepali Terai', 'Fruits', 70, 1, '', '1531141589_watermelon-regular.jpg', 'spring'),
(35, 'Orange', 'Gorkha', 'Fruits', 90, 1, '', 'images_orange_czj9k2.jpg', 'winter'),
(36, 'Banana', 'Nepali Terai', 'Fruits', 120, 1, '', '1531141470_banana-poovam.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_product_id` int(10) NOT NULL,
  `stock_product_quentity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(3) NOT NULL,
  `user_first_name` varchar(30) NOT NULL,
  `user_last_name` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(10) NOT NULL,
  `user_address_no` varchar(5) NOT NULL,
  `user_address_street` varchar(30) NOT NULL,
  `user_address_town` varchar(30) NOT NULL,
  `user_tp` char(10) NOT NULL,
  `user_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_first_name`, `user_last_name`, `user_name`, `user_password`, `user_address_no`, `user_address_street`, `user_address_town`, `user_tp`, `user_email`) VALUES
(1, 'jadu', 'jadu', 'Jadu', 'jadu123', 'Nepal', 'Chabahil', 'Chabahil', '9841000000', 'aashutosh@jadu.com'),
(9, 'aashish', 'rupakheti', 'aashish', 'Aashish@2', 'Syuch', 'aagamantole', 'kathmandu', '9843806864', 'aashishrupakheti@gmail.com'),
(14, 'ashu', 'a', 'Ashu', 'ashu', '1', '2', 'ktm', '9874563210', 'a@'),
(15, 'Rujan', 'Ranjit', 'rujan', 'rujan', 'soyam', 'thulo varyang', 'Kathmandu', '1234567891', 'rujan@gmail.com'),
(16, 'admin', 'admin', 'admin', 'admin', 'sdjas', 'dad', 'sdf', '5985235566', 'rujan@gmail.com'),
(17, 'c', 'd', 'a', 'b', 'e', 'f', 'y', 'r', 'h');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `cart_user_id` (`cart_user_id`),
  ADD KEY `cart_product_id` (`cart_product_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notifi_id`),
  ADD KEY `notifi_cust_id` (`notifi_cust_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_user_id` (`order_user_id`),
  ADD KEY `order_product_id` (`order_product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock_product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notifi_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`cart_user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`cart_product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`notifi_cust_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`order_user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`order_product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`stock_product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
